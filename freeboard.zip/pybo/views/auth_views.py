import functools

from flask import Blueprint, url_for, render_template, flash, request, session, g
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import redirect

from .. import db
from ..forms import UserCreateForm, UserLoginForm,InformationForm
from ..models import User, Question, Answer, Comment

bp = Blueprint('auth', __name__, url_prefix='/auth')


@bp.route('/signup/', methods=('GET', 'POST'))
def signup():
    form = UserCreateForm()
    if request.method == 'POST' and form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if not user:
            user = User(username=form.username.data,
                        password=generate_password_hash(form.password1.data),
                        email=form.email.data)
            db.session.add(user)
            db.session.commit()
            return redirect(url_for('main.index'))
        else:
            flash('이미 존재하는 사용자입니다.')
    return render_template('auth/signup.html', form=form)


@bp.route('/login/', methods=('GET', 'POST'))
def login():
    form = UserLoginForm()
    if request.method == 'POST' and form.validate_on_submit():
        error = None
        user = User.query.filter_by(username=form.username.data).first()
        if not user:
            error = "존재하지 않는 사용자입니다."
        elif not check_password_hash(user.password, form.password.data):
            error = "비밀번호가 올바르지 않습니다."
        if error is None:
            session.clear()
            session['user_id'] = user.id
            return redirect(url_for('main.index'))
        flash(error)
    return render_template('auth/login.html', form=form)


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')
    if user_id is None:
        g.user = None
    else:
        g.user = User.query.get(user_id)


@bp.route('/logout/')
def logout():
    session.clear()
    return redirect(url_for('main.index'))


def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))
        return view(**kwargs)
    return wrapped_view

@bp.route('/profile/<string:board>/<int:auth_id>')
def profile(auth_id, board):
    user = User.query.get_or_404(auth_id)
    if board == None :
        board = 'base'

    # 입력 파라미터
    page = request.args.get('page', type=int, default=1)

    list = None
    # 페이징
    if board =='questions':
        question_list = Question.query.filter(Question.user_id.ilike(auth_id)).order_by(Question.create_date.desc())
        list = question_list.paginate(page, per_page=10)
    elif board =='answer':
        answer_list = Answer.query.filter(Answer.user_id.ilike(auth_id)).order_by(Answer.create_date.desc())
        list = answer_list.paginate(page, per_page=10)
    elif board =='comment':
        comment_list = Comment.query.filter(Comment.user_id.ilike(auth_id)).order_by(Comment.create_date.desc())
        list = comment_list.paginate(page, per_page=10)

    # rank
    rank = User.query.all()[:3]
    rank.sort(reverse=True, key=lambda users: users.score())

    return render_template('auth/profile.html', list=list, user=user, board=board, page=page, rank=rank)

@bp.route('/modify/<int:user_id>', methods=('GET', 'POST'))
@login_required
def modify(user_id):
    # rank
    rank = User.query.all()[:3]
    rank.sort(reverse=True, key=lambda users: users.score())

    user = User.query.get_or_404(user_id)
    if g.user != user:
        flash('수정권한이 없습니다')
        return redirect(url_for('auth.profile', board='base', auth_id=user_id, rank=rank))
    if request.method == 'POST':
        form = InformationForm()
        if form.validate_on_submit():
            form.populate_obj(user)
            db.session.commit()
            return redirect(url_for('auth.profile', board='base', auth_id=user_id, rank=rank))
    else:
        form = InformationForm(obj=user)

    return render_template('auth/information_form.html', form=form, rank=rank)


@bp.route('/ranking/')
def ranking():
    list = User.query.all()[:100]
    list.sort(reverse=True, key=lambda user: user.score())
    return render_template('ranking/ranking_list.html', list=list)

